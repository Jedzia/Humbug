# HumbugCore #

The chaining core library of *Humbug*.

**Description here**.

## Dependencies ## 

- TARGET_LINK Boost
	* program_options, filesystem, system, regex, serialization
- TARGET_LINK HumbugLib
    * provides debug helpers.
- TARGET_LINK HumbugShared
	* game objects, VFS
- TARGET_LINK GuiLib
- TARGET_LINK luabind
- **complete the list**
