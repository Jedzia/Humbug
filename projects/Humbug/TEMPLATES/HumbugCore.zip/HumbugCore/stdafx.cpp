/*---------------------------------------------------------*/
/*!
 * This file is part of Humbug, the template processor.
 * License details can be found in the file COPYING.
 * Copyright (c) 2011, EvePanix. All rights reserved.
 *
 * \brief      This file contains the implementation of
 *             the stdafx class.
 * \folder     $(folder)
 * \file       stdafx.cpp
 * \date       2011-09-17
 * \author     Jedzia.
 *
 * modified    2011-09-17, Jedzia
 */
/*---------------------------------------------------------*/


#include "stdafx.h"
